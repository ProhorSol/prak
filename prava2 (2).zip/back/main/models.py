from django.db import models
from django.utils import timezone
from django.urls import reverse
from django.contrib.auth.models import User

class Products(models.Model):
    name = models.CharField('Название', max_length = 200, null=True)
    name_2 = models.CharField('Название категории', max_length = 200, null=True)
    price = models.IntegerField(null=True)

    @property
    def photo_url(self):
        if self.photo and hasattr(self.photo, 'url'):
            return self.photo.url
        
    def __str__(self):
        return self.name
    
    class Meta:
        verbose_name = 'продукция'
        verbose_name_plural = 'Продукция'

class Comment(models.Model):
    comm = models.ForeignKey(Products, related_name='comments', on_delete = models.PROTECT)
    name = models.ForeignKey(User, on_delete = models.PROTECT)
    body = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
        
    def __str__(self):
        return f"{self.name} - {self.comm}"
    
    class Meta:
        verbose_name = 'комментарий'
        verbose_name_plural = 'Комментарии'
