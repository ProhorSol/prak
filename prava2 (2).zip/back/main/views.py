from django.shortcuts import render, get_object_or_404

from django.shortcuts import render
from .models import Products
from .models import Comment
from .forms import CommentForm

def home(request):
    prods = Products.objects.all()
    return render(request, 'main/main.html', {'prods' : prods})

def about(request):
    return render(request, 'main/about.html')

def buy(request):
    return render(request, 'main/buy.html')

def post_detail(request, pk):
    comm = get_object_or_404(Products, id=pk)
    comment = Comment.objects.filter(comm=pk)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            form = form.save(commit=False)
            form.name_id = request.user.id
            form.comm_id = comm.id
            form.save()
    else:
        form = CommentForm()

    return render(request, 'main/house_detail.html', {
        "comm":comm,
        "comment":comment,
        "form":form
        })