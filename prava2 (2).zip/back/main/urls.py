from django.urls import path
from django.conf.urls.static import static
from . import views
from .views import *
from back import settings

urlpatterns = [
    path('', home, name="home"),
    path('about/', about, name = 'about'),
    path('buy/', buy, name = 'buy'),
    path('post/<int:pk>/', post_detail, name='post_detail'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

